require("config.lazy")
require("config.cmds")


